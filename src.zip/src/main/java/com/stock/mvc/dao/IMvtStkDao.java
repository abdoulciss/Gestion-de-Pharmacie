package com.stock.mvc.dao;

import com.stock.mvc.entites.MvtStk;

public interface IMvtStkDao extends IGenericDao<MvtStk> {

}
