package com.stock.mvc.dao;

import com.stock.mvc.entites.Vente;

public interface IVenteDao  extends IGenericDao<Vente> {

}
