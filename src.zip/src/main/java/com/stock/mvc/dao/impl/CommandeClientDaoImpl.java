package com.stock.mvc.dao.impl;

import com.stock.mvc.dao.ICommandeClientDao;
import com.stock.mvc.entites.CommandeClient;

public class CommandeClientDaoImpl extends GenericDaoImpl<CommandeClient> implements ICommandeClientDao {

}
