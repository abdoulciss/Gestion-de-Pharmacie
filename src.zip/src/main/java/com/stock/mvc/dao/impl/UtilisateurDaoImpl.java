package com.stock.mvc.dao.impl;

import com.stock.mvc.dao.IUtilisateurDao;
import com.stock.mvc.entites.Utilisateur;

public class UtilisateurDaoImpl  extends GenericDaoImpl<Utilisateur> implements IUtilisateurDao {

}
