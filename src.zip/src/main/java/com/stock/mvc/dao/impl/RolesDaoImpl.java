package com.stock.mvc.dao.impl;

import com.stock.mvc.dao.IRolesDao;
import com.stock.mvc.entites.Roles;

public class RolesDaoImpl extends GenericDaoImpl<Roles> implements IRolesDao {

}
