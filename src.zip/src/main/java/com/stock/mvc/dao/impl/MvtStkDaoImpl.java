package com.stock.mvc.dao.impl;

import com.stock.mvc.dao.IMvtStkDao;
import com.stock.mvc.entites.MvtStk;

public class MvtStkDaoImpl  extends GenericDaoImpl<MvtStk> implements IMvtStkDao {

}