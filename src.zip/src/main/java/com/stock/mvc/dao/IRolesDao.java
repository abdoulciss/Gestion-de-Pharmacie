package com.stock.mvc.dao;

import com.stock.mvc.entites.Roles;

public interface IRolesDao extends IGenericDao<Roles>{

}
