package com.stock.mvc.dao.impl;

import com.stock.mvc.dao.IVenteDao;
import com.stock.mvc.entites.Vente;

public class VenteDaoImpl  extends GenericDaoImpl<Vente> implements IVenteDao {

}
