package com.stock.mvc.dao.impl;

import com.stock.mvc.dao.IClientDao;
import com.stock.mvc.entites.Client;

public class ClientDaoImpl extends GenericDaoImpl<Client> implements IClientDao {

}
